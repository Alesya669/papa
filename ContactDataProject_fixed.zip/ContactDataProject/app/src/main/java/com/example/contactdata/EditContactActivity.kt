package com.example.contactdata

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EditContactActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "extra_mode"
        const val MODE_ADD = "add"
        const val MODE_EDIT = "edit"
    }

    private lateinit var viewModel: ContactsViewModel
    private lateinit var etName: EditText
    private lateinit var etPhone: EditText
    private lateinit var etEmail: EditText
    private lateinit var etAddress: EditText
    private var mode: String = MODE_ADD

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_contact)

        viewModel = (application as ContactsApplication).contactsViewModel

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_ADD

        val title = findViewById<TextView>(R.id.tvEditorTitle)
        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        etEmail = findViewById(R.id.etEmail)
        etAddress = findViewById(R.id.etAddress)

        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnCancel = findViewById<Button>(R.id.btnCancel)

        if (mode == MODE_EDIT) {
            title.text = "Изменение контакта"
            fillFields()
        } else {
            title.text = "Добавление контакта"
        }

        btnSave.setOnClickListener {
            saveContact()
        }

        btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun fillFields() {
        val contact = viewModel.getCurrentContact()
        if (contact == null) {
            Toast.makeText(this, "Контакт не найден", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        etName.setText(contact.name)
        etPhone.setText(contact.phone)
        etEmail.setText(contact.email)
        etAddress.setText(contact.address)
    }

    private fun saveContact() {
        val name = etName.text.toString().trim()
        val phone = etPhone.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val address = etAddress.text.toString().trim()

        if (name.isBlank()) {
            etName.error = "Введите ФИО"
            etName.requestFocus()
            return
        }

        if (phone.isBlank()) {
            etPhone.error = "Введите телефон"
            etPhone.requestFocus()
            return
        }

        if (email.isBlank()) {
            etEmail.error = "Введите электронную почту"
            etEmail.requestFocus()
            return
        }

        if (address.isBlank()) {
            etAddress.error = "Введите адрес"
            etAddress.requestFocus()
            return
        }

        val contact = Contact(name, phone, email, address)

        if (mode == MODE_ADD) {
            viewModel.addContact(contact)
            Toast.makeText(this, "Контакт добавлен", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.updateCurrentContact(contact)
            Toast.makeText(this, "Изменения сохранены", Toast.LENGTH_SHORT).show()
        }

        setResult(RESULT_OK)
        finish()
    }
}
