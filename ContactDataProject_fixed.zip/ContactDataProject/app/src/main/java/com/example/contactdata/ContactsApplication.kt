package com.example.contactdata

import android.app.Application

/** Единый экземпляр ViewModel для всех экранов приложения. */
class ContactsApplication : Application() {
    val contactsViewModel: ContactsViewModel by lazy {
        ContactsViewModel()
    }
}
