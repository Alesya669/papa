package com.example.contactdata

data class Contact(
    val name: String,
    val phone: String,
    val email: String,
    val address: String
)
