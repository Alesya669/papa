package com.example.contactdata

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ContactsViewModel : ViewModel() {

    private val _contacts = MutableLiveData<List<Contact>>(
        listOf(
            Contact(
                "Иванов Иван Иванович",
                "+7 900 000-00-00",
                "ivanov@mail.ru",
                "Москва"
            ),
            Contact(
                "Петрова Анна Сергеевна",
                "+7 901 111-11-11",
                "petrova@mail.ru",
                "Санкт-Петербург"
            )
        )
    )
    val contacts: LiveData<List<Contact>> = _contacts

    private val _selectedIndex = MutableLiveData(0)
    val selectedIndex: LiveData<Int> = _selectedIndex

    fun getCurrentContact(): Contact? {
        val list = _contacts.value.orEmpty()
        val index = _selectedIndex.value ?: 0
        return list.getOrNull(index)
    }

    fun selectNext() {
        val list = _contacts.value.orEmpty()
        if (list.isNotEmpty()) {
            val current = _selectedIndex.value ?: 0
            _selectedIndex.value = (current + 1) % list.size
        }
    }

    fun selectPrevious() {
        val list = _contacts.value.orEmpty()
        if (list.isNotEmpty()) {
            val current = _selectedIndex.value ?: 0
            _selectedIndex.value = (current - 1 + list.size) % list.size
        }
    }

    fun addContact(contact: Contact) {
        val updated = _contacts.value.orEmpty().toMutableList()
        updated.add(contact)
        _contacts.value = updated
        _selectedIndex.value = updated.lastIndex
    }

    fun updateCurrentContact(contact: Contact) {
        val updated = _contacts.value.orEmpty().toMutableList()
        val index = _selectedIndex.value ?: 0
        if (index in updated.indices) {
            updated[index] = contact
            _contacts.value = updated
        }
    }
}
