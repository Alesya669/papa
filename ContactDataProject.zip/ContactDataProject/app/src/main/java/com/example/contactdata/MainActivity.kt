package com.example.contactdata

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: ContactsViewModel
    private lateinit var tvContact: TextView
    private lateinit var tvCounter: TextView
    private lateinit var btnEdit: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = ViewModelProvider(
            application as ContactsApplication
        )[ContactsViewModel::class.java]

        tvContact = findViewById(R.id.tvContact)
        tvCounter = findViewById(R.id.tvCounter)
        btnEdit = findViewById(R.id.btnEdit)

        val btnPrevious = findViewById<ImageButton>(R.id.btnPrevious)
        val btnNext = findViewById<ImageButton>(R.id.btnNext)
        val btnAdd = findViewById<Button>(R.id.btnAdd)

        viewModel.contacts.observe(this) { renderContact() }
        viewModel.selectedIndex.observe(this) { renderContact() }

        btnPrevious.setOnClickListener {
            viewModel.selectPrevious()
        }

        btnNext.setOnClickListener {
            viewModel.selectNext()
        }

        btnAdd.setOnClickListener {
            openEditor(EditContactActivity.MODE_ADD)
        }

        btnEdit.setOnClickListener {
            if (viewModel.getCurrentContact() != null) {
                openEditor(EditContactActivity.MODE_EDIT)
            }
        }
    }

    private fun openEditor(mode: String) {
        startActivity(
            Intent(this, EditContactActivity::class.java)
                .putExtra(EditContactActivity.EXTRA_MODE, mode)
        )
    }

    private fun renderContact() {
        val list = viewModel.contacts.value.orEmpty()
        val index = viewModel.selectedIndex.value ?: 0
        val contact = list.getOrNull(index)

        if (contact == null) {
            tvContact.text = "Контактов пока нет.\nНажмите «Добавить», чтобы создать первый контакт."
            tvCounter.text = "Список пуст"
            btnEdit.isEnabled = false
            return
        }

        tvContact.text = """
            ФИО: ${contact.name}

            Телефон: ${contact.phone}

            Email: ${contact.email}

            Адрес: ${contact.address}
        """.trimIndent()

        tvCounter.text = "Контакт ${index + 1} из ${list.size}"
        btnEdit.isEnabled = true
    }
}
