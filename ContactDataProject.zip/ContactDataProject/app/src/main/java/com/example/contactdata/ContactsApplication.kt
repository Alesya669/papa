package com.example.contactdata

import android.app.Application
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner

/**
 * Единый владелец ViewModel для обеих Activity.
 * Благодаря этому список контактов общий для главного экрана
 * и экрана добавления/изменения.
 */
class ContactsApplication : Application(), ViewModelStoreOwner {

    private val applicationViewModelStore: ViewModelStore by lazy {
        ViewModelStore()
    }

    override val viewModelStore: ViewModelStore
        get() = applicationViewModelStore

    override fun onTerminate() {
        super.onTerminate()
        applicationViewModelStore.clear()
    }
}
